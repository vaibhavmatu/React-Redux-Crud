import React,{useState} from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";


const AddUser = () => {
    const [state, setState] = useState({
        firstName: "",
        lastName: "",
        emailId: "", 
    })

    const [error, setError] = useState("")

    let navigate = useNavigate();
    let dispatch = useDispatch();

    const { firstName, lastName, emailId } = state;
     
    const handleInput = (e) =>{
        let {name, value} = e.target;
        setState({...state, [name]:value});
    }

    const handleSubmit = (e)=>{
        e.preventDefault();
        if(!firstName || !lastName || !emailId){
            setError("Please fill all inputs")
        } else{
            dispatch(AddUser(state));
            navigate("/");
            setError("")

        }
    }
  return (
    <div>
        <Button style={{width: "100px", marginTop:"200px"}} variant="contained" color="primary" type="submit" onClick={()=>navigate("/ ")}> 
          GO Back
        </Button>
        <h2>Add Employee</h2>
        {error && <h3 style={{color: "red"}}>{error}</h3>}
      
      <Box onSubmit={handleSubmit}
        component="form"
        sx={{
          "& > :not(style)": { m: 1, width: "25ch" },
        }}
        noValidate
        autoComplete="off"
      >
        <TextField id="standard-basic" label="firstName" variant="standard" value={firstName} name="firstName" type="text" onChange={handleInput} />
        <br />
        <TextField id="standard-basic" label="lastName" variant="standard" value={lastName} name="lastName" type="text" onChange={handleInput} />
        <br />
        <TextField id="standard-basic" label="emailId" variant="standard" value={emailId} name="emailId" type="email" onChange={handleInput} />
        <br />
        <Button style={{width: "100px"}} variant="contained" color="primary" type="submit" onChange={handleInput}> 
          Submit
        </Button>
      </Box>
    
      );
    </div>
  );
};

export default AddUser;
